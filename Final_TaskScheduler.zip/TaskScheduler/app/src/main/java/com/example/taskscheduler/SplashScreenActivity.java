//CECS453
//Mike Zeng & Justin Mabutas
//Final Project
package com.example.taskscheduler;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Window;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Purpose: Makes a splashscreen before app starts.
 * If keepedLoggedIn, goes to home page
 * Else, goes to log in page
 */
public class SplashScreenActivity extends AppCompatActivity {
    boolean isChecked;
    String username = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.splash_screen);

        SharedPreferences sharedpref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        isChecked = sharedpref.getBoolean("isChecked", false);
        username = sharedpref.getString("username", "");

        getSupportActionBar().hide();
        SplashScreen splash = new SplashScreen();
        splash.start();
    }

//    Splash Screen Object. Waits 3 seconds and then changes activities.
    public class SplashScreen extends Thread{
        public void run(){
            try{
                sleep(3000);
            }catch(InterruptedException e){
                e.printStackTrace();
            }
            if(isChecked){
                Intent intent = new Intent(SplashScreenActivity.this, HomeScreenSlidePagerActivity.class);
                intent.putExtra("intent_uname", username);
                SplashScreenActivity.this.finish();
                startActivity(intent);
            }else{
                Intent intent = new Intent(SplashScreenActivity.this, MainActivity.class);
                SplashScreenActivity.this.finish();
                startActivity(intent);
            }
        }
    }
}