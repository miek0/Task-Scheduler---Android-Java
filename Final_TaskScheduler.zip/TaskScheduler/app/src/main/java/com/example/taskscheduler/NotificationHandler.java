//CECS453
//Mike Zeng & Justin Mabutas
//Final Project
package com.example.taskscheduler;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

// Notification related classes work, but time restrains prevented further implementation.
public class NotificationHandler extends Application {

//    Two channels, one for our AI scheduled notifications, one for user scheduled notifications.
    public static final String AI_REMINDER_CHANNEL = "ai_channel";
    public static final String USER_REMINDER_CHANNEL = "user_channel";

    @Override
    public void onCreate() {
        super.onCreate();

        createNotificationChannels();
    }

//    Creates channels for notifications to be sent through.
    private void createNotificationChannels() {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ai_channel = new NotificationChannel(
                    AI_REMINDER_CHANNEL,
                    "AI Channel",
                    NotificationManager.IMPORTANCE_HIGH
            );
            ai_channel.setDescription("This is the notification channel for ai scheduled reminders.");

            NotificationChannel user_channel = new NotificationChannel(
                    USER_REMINDER_CHANNEL,
                    "User Channel",
                    NotificationManager.IMPORTANCE_HIGH
            );
            ai_channel.setDescription("This is the notification channel for user scheduled reminders.");

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(ai_channel);
            manager.createNotificationChannel(user_channel);
        }
    }
}
