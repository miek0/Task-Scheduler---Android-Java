//CECS453
//Mike Zeng & Justin Mabutas
//Final Project
package com.example.taskscheduler;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Activity responsible for changing the user profile information
 */
public class ProfileEditActivity extends AppCompatActivity {
    private static final String TAG = "ProfileEdit";
    private EditText new_pw_text, confirm_pw_text, new_fname_text, new_lname_text;
    private Button cancel_btn, save_btn;
    String username = "";
    UserDatabase mUserDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_edit);
        username = getIntent().getStringExtra("username");
        Log.d(TAG, "username: "+username);

        new_pw_text = findViewById(R.id.new_pw);
        confirm_pw_text = findViewById(R.id.confirm_new_pw);
        new_fname_text = findViewById(R.id.new_fname);
        new_lname_text = findViewById(R.id.new_lname);
        save_btn = findViewById(R.id.save_profile);
        cancel_btn = findViewById(R.id.cancel_edit_profile);
        mUserDatabase = new UserDatabase(this);

        save_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update_user(username);

                ProfileEditActivity.this.finish();

                Intent intent = new Intent(v.getContext(), HomeScreenSlidePagerActivity.class);
                startActivity(intent);

                toastMessage("Your profile has been updated.");

            }
        });
        cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ProfileEditActivity.this.finish();
                Intent intent = new Intent(v.getContext(), HomeScreenSlidePagerActivity.class);
                startActivity(intent);
            }
        });
    }

    //Changes the user's fields that they inputted in. If left blank, nothing is changed.
    public void update_user(String uName) {
        String newpw = new_pw_text.getText().toString();
        String newfname = new_fname_text.getText().toString();
        String newlname = new_lname_text.getText().toString();
        int itemID = -1;
        String oldpw = "";
        String oldfname = "";
        String oldlname = "";
        Cursor data = mUserDatabase.getItemID(uName); //get the id associated with that name
        while (data.moveToNext()) {
            itemID = data.getInt(0);
        }
        data = mUserDatabase.getItemField(itemID, "password");
        while (data.moveToNext()) {
            oldpw = data.getString(0);
        }
        data = mUserDatabase.getItemField(itemID, "firstname");
        while (data.moveToNext()) {
            oldfname = data.getString(0);
        }
        data = mUserDatabase.getItemField(itemID, "lastname");
        while (data.moveToNext()) {
            oldlname = data.getString(0);
        }

        if((!newpw.isEmpty()) && confirm_password())
            mUserDatabase.updateField(newpw, oldpw, itemID, "password");
        if(!newfname.isEmpty())
            mUserDatabase.updateField(newfname, oldfname, itemID, "firstname");
        if(!newlname.isEmpty())
            mUserDatabase.updateField(newlname, oldlname, itemID, "lastname");
    }


    //    Check to see if password and confirm_password matched up.
    public boolean confirm_password() {
        if(new_pw_text.getText().toString().equals(confirm_pw_text.getText().toString()))
            return true;
        toastMessage("Passwords must match.");
        return false;
    }

//    Displays toast message
    private void toastMessage(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
}