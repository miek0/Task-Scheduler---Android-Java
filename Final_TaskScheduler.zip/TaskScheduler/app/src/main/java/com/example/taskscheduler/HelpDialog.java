//CECS453
//Mike Zeng & Justin Mabutas
//Final Project
package com.example.taskscheduler;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

/**
 * Help Dialog which displays a dialog when the user presses on the help button.
 * This dialog will display common questions/issues a typical user will experience.
 */
public class HelpDialog extends AppCompatDialogFragment {
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("FAQ")
                .setMessage("Swipe left for creating new tasks! \nClick on existing tasks to edit them! \nContact us at first.last@student.school.edu")
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
        return builder.create();
    }
}