package com.example.taskscheduler;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.text.DateFormat;
import java.util.Calendar;

public class NewTaskFragment extends Fragment {

    UserDatabase mUserDatabase;
    TaskDatabase mTaskDatabase;
    private EditText task_title_edit;
    private EditText task_description_field;
    private Button pick_due_date;
    private TextView due_date_text;
    private RadioButton progress1_btn;
    private RadioButton progress2_btn;
    private Button finish_btn;
    private String[] task_fields;

    private Calendar calendar;
    private int day,month,year;

    private String username = "";
    private String taskname = "";

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.new_task_fragment,container, false);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(rootView.getContext());
        final SharedPreferences.Editor editor = prefs.edit();
        username = prefs.getString("username",username);

        mUserDatabase = new UserDatabase(this.getActivity());
        mTaskDatabase = new TaskDatabase(this.getActivity());
        task_title_edit = rootView.findViewById(R.id.task_title_edit);
        task_description_field = rootView.findViewById(R.id.task_description_field);
        pick_due_date = rootView.findViewById(R.id.pick_due_date);
        due_date_text = rootView.findViewById(R.id.due_date_text);
        progress1_btn = rootView.findViewById(R.id.progress1_btn);
        progress2_btn = rootView.findViewById(R.id.progress2_btn);
        finish_btn = rootView.findViewById(R.id.finish_btn);

        calendar = Calendar.getInstance();
        day = calendar.get(Calendar.DAY_OF_MONTH);
        month = calendar.get(Calendar.MONTH);
        year = calendar.get(Calendar.YEAR);
//        January starts at 0
        month+=1;

        String format_date = DateFormat.getDateInstance().format(calendar.getTime());
        due_date_text.setText(format_date);

        pick_due_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(NewTaskFragment.this.getActivity(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int temp_year, int temp_month, int temp_day) {
                        month = temp_month+1;
                        day=temp_day;
                        year=temp_year;
                        due_date_text.setText(temp_month+1 + "/" + temp_day + "/" + temp_year);
                    }
                }, year, month-1, day);
                datePickerDialog.show();
            }
        });
        finish_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(), task_title_edit.getText(), Toast.LENGTH_SHORT).show();
            }
        });

        finish_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                create_new_task();
                Intent intent = new Intent(v.getContext(), HomeScreenSlidePagerActivity.class);
                NewTaskFragment.this.getActivity().finish();
                editor.putString("taskname", taskname);
                editor.commit();
                startActivity(intent);
                toastMessage("Your task has been added.");
            }
        });

        return rootView;
    }

    public void create_new_task(){
        int userID = -1;
        Cursor user_cursor = mUserDatabase.getItemID(username);
        while (user_cursor.moveToNext()) {
            userID = user_cursor.getInt(0);
        }
        taskname = task_title_edit.getText().toString();
        String prog = "";
        if(progress1_btn.isChecked()){
            prog = "Not Started";
        }else if(progress2_btn.isChecked()){
            prog = "Started";
        }
        task_fields = new String[]{String.valueOf(userID), taskname, task_description_field.getText().toString(),
                due_date_text.getText().toString(), prog};
                mTaskDatabase.addData(task_fields);
    }

    private void toastMessage(String message) {
        Toast.makeText(this.getActivity(), message, Toast.LENGTH_SHORT).show();
    }
}